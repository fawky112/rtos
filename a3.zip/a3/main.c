/* ================== Includes ================== */
#include "FreeRTOS.h"
#include "task.h"
#include "basic_io.h"
#include "TM4C123.h"

/* ================== Global Handles ================== */
TaskHandle_t xInterruptTaskHandle = NULL;

/* ================== Prototypes ================== */
static void vInterruptProcessorTask(void *pvParams);
static void vStatusTask(void *pvParams);
static void prvInitTimer1(void);

/* =================================================== */

int main(void)
{
    /* Create task responsible for handling interrupt events */
    xTaskCreate(vInterruptProcessorTask,
                "INT_Task",
                256,
                NULL,
                3,
                &xInterruptTaskHandle);

    /* Create background status task */
    xTaskCreate(vStatusTask,
                "Status_Task",
                256,
                NULL,
                1,
                NULL);

    /* Ensure task was created successfully */
    if (xInterruptTaskHandle == NULL)
    {
        while (1);
    }

    /* Initialize Timer1 after task creation */
    prvInitTimer1();

    /* Start RTOS scheduler */
    vTaskStartScheduler();

    while (1);
}

/* =================================================== */
/* Task: Waits for interrupt notification and processes it */

static void vInterruptProcessorTask(void *pvParams)
{
    (void) pvParams;

    for (;;)
    {
        /* Block until notification from ISR */
        ulTaskNotifyTake(pdTRUE, portMAX_DELAY);

        /* Action after interrupt */
        vPrintString("INT Task: Event triggered -> Processing done\n");
    }
}

/* =================================================== */
/* Task: Periodic system monitor */

static void vStatusTask(void *pvParams)
{
    (void) pvParams;

    for (;;)
    {
        vTaskDelay(pdMS_TO_TICKS(1000));

        vPrintString("Status Task: System Alive\n");
    }
}

/* =================================================== */
/* Timer1 Initialization */

static void prvInitTimer1(void)
{
    /* Enable clock for Timer1 */
    SYSCTL->RCGCTIMER |= (1U << 1);

    /* Dummy delay for stabilization */
    volatile uint32_t delay = SYSCTL->RCGCTIMER;

    /* Disable Timer before configuration */
    TIMER1->CTL &= ~(1U << 0);

    /* Configure as 32-bit timer */
    TIMER1->CFG = 0x0;

    /* Set periodic mode */
    TIMER1->TAMR = 0x2;

    /* Load value for ~1 second */
    TIMER1->TAILR = 16000000;

    /* Enable timeout interrupt */
    TIMER1->IMR |= (1U << 0);

    /* Configure NVIC priority */
    NVIC_SetPriority(TIMER1A_IRQn, 5);

    /* Enable interrupt in NVIC */
    NVIC_EnableIRQ(TIMER1A_IRQn);

    /* Enable Timer */
    TIMER1->CTL |= (1U << 0);
}

/* =================================================== */
/* Timer1 Interrupt Handler */

void TIMER1A_Handler(void)
{
    BaseType_t xSwitchRequired = pdFALSE;

    /* Clear interrupt flag */
    TIMER1->ICR |= (1U << 0);

    /* Notify task safely from ISR */
    if (xInterruptTaskHandle != NULL)
    {
        vTaskNotifyGiveFromISR(xInterruptTaskHandle, &xSwitchRequired);
    }

    /* Perform context switch if needed */
    portYIELD_FROM_ISR(xSwitchRequired);
}

/* =================================================== */
/* FreeRTOS Hooks */

void vApplicationMallocFailedHook(void)
{
    while (1);
}

void vApplicationStackOverflowHook(TaskHandle_t pxTask, char *pcTaskName)
{
    (void) pxTask;
    (void) pcTaskName;
    while (1);
}

void vApplicationIdleHook(void)
{
}

void vApplicationTickHook(void)
{
}