/* ===================== Includes ===================== */
#include "FreeRTOS.h"
#include "task.h"
#include "basic_io.h"
#include "TM4C123.h"

/* ===================== Configuration ===================== */
#define USE_YIELD_FROM_ISR    1

/* ===================== Global Variables ===================== */
TaskHandle_t xTaskBHandle = NULL;
volatile uint32_t ulISR_Timestamp = 0;

/* ===================== Function Prototypes ===================== */
static void vTaskA(void *pvParameters);
static void vTaskB(void *pvParameters);
static void vSetupTimer1(void);

/* ===================== Main ===================== */
int main(void)
{
    /* Create Tasks */
    xTaskCreate(vTaskA, "TaskA", 240, NULL, 1, NULL);
    xTaskCreate(vTaskB, "TaskB", 240, NULL, 3, &xTaskBHandle);

    /* Ensure Task B handle is valid */
    if (xTaskBHandle == NULL)
    {
        while (1);
    }

    /* Initialize Timer Interrupt */
    vSetupTimer1();

    /* Start Scheduler */
    vTaskStartScheduler();

    /* Should never reach here */
    for (;;);
}

/* ===================== Task A ===================== */
static void vTaskA(void *pvParameters)
{
    (void)pvParameters;

    for (;;)
    {
        vPrintString("Task A (low priority): running...\n");
        vTaskDelay(pdMS_TO_TICKS(500));
    }
}

/* ===================== Task B ===================== */
static void vTaskB(void *pvParameters)
{
    (void)pvParameters;

    uint32_t ulWakeTime;

    for (;;)
    {
        /* Wait for ISR notification */
        ulTaskNotifyTake(pdTRUE, portMAX_DELAY);

        /* Capture time when task wakes */
        ulWakeTime = SysTick->VAL;

        /* Calculate latency */
        uint32_t ulLatency;

        if (ulISR_Timestamp >= ulWakeTime)
        {
            ulLatency = ulISR_Timestamp - ulWakeTime;
        }
        else
        {
            ulLatency = ulISR_Timestamp + (SysTick->LOAD + 1 - ulWakeTime);
        }

        /* Print result */
        vPrintStringAndNumber(
            "Task B: Latency (SysTick counts) = ",
            (long)ulLatency
        );

#if USE_YIELD_FROM_ISR
        vPrintString(" [Immediate Switch]\n");
#else
        vPrintString(" [Delayed Switch]\n");
#endif
    }
}

/* ===================== Timer1 Setup ===================== */
static void vSetupTimer1(void)
{
    /* Enable clock for Timer1 */
    SYSCTL->RCGCTIMER |= (1U << 1);

    /* Small delay for stabilization */
    for (volatile int i = 0; i < 1000; i++);

    /* Disable Timer before configuration */
    TIMER1->CTL &= ~(1U << 0);

    /* Configure Timer */
    TIMER1->CFG  = 0x0;   /* 32-bit mode */
    TIMER1->TAMR = 0x2;   /* Periodic mode */

    /* Set reload value (2 seconds @ 16 MHz) */
    TIMER1->TAILR = 32000000U;

    /* Enable timeout interrupt */
    TIMER1->IMR |= (1U << 0);

    /* Set interrupt priority */
    NVIC_SetPriority(TIMER1A_IRQn, 5);

    /* Enable interrupt in NVIC */
    NVIC_EnableIRQ(TIMER1A_IRQn);

    /* Start Timer */
    TIMER1->CTL |= (1U << 0);
}

/* ===================== ISR ===================== */
void TIMER1A_Handler(void)
{
    BaseType_t xHigherPriorityTaskWoken = pdFALSE;

    /* Clear interrupt flag */
    TIMER1->ICR = (1U << 0);

    /* Capture timestamp */
    ulISR_Timestamp = SysTick->VAL;

    /* Notify Task B */
    if (xTaskBHandle != NULL)
    {
        vTaskNotifyGiveFromISR(xTaskBHandle, &xHigherPriorityTaskWoken);
    }

#if USE_YIELD_FROM_ISR
    portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
#endif
}

/* ===================== Hooks ===================== */
void vApplicationMallocFailedHook(void)
{
    while (1);
}

void vApplicationStackOverflowHook(TaskHandle_t pxTask, char *pcTaskName)
{
    (void)pxTask;
    (void)pcTaskName;

    while (1);
}

void vApplicationIdleHook(void) {}
void vApplicationTickHook(void) {}